from  django.urls import path
from .views import*

urlpatterns = [
    path('',index),
    path('blogdetail',blogdetail,name='blogdetail'),
    path('coursedetail',coursedetail,name='coursedetail'),
]
