from django.shortcuts import render
from .models import*
from django.core.paginator import InvalidPage, Paginator, EmptyPage, InvalidPage


def index(request):
    categories = Category.objects.all()
    blogs = Blog.objects.all()
    latest = Blog.objects.all().order_by('pk')
    paginator = Paginator(blogs,3)
    popular = Blog.objects.all().order_by('views')[:4]
    try:
        page = int(request.GET.get('page','1'))
    except:
        page = 1
    try:
        blogPerpage = paginator.page(page)
    except(EmptyPage,InvalidPage):
        blogPerpage = paginator.page(paginator.num_pages)

    return render(request,"app/index.html",{'categories':categories,'blogs':blogs,'latest':latest,'blogs':blogPerpage,'popular':popular})

def blogdetail(request):
    return render(request,"app/blogdetail.html")

def coursedetail(request):
    return render(request,"app/coursedetail.html")