from django.contrib import admin
from django_summernote.admin import SummernoteModelAdmin
from .models import*
admin.site.register(Category)

class BlogAdmin(SummernoteModelAdmin):
    summernote_fields = ('detail','description')

admin.site.register(Blog,BlogAdmin)
